// Booking offers: shared helpers for the request -> offer -> confirmed flow.
// Status rules live in the database (send_booking_offer / respond_to_booking_offer RPCs);
// these helpers only format and explain.

import { MUZICALIST_LOGO_DATA_URI } from "@/lib/contractLogo";

export type BookingStatus = "pending" | "offered" | "accepted" | "rejected" | string;

export interface BookingOfferFields {
  id: string;
  profile_id: string;
  requester_name: string;
  requester_user_id?: string | null;
  event_date: string;
  event_end_date?: string | null;
  event_type?: string | null;
  message?: string | null;
  status: BookingStatus;
  offer_price?: number | string | null;
  offer_currency?: string | null;
  offer_note?: string | null;
  offer_sent_at?: string | null;
  confirmed_at?: string | null;
  declined_by?: "artist" | "requester" | null | string;
}

/** Columns needed by the offer UI (contact columns stay private, see get_booking_contact). */
export const BOOKING_OFFER_COLUMNS =
  "offer_price, offer_currency, offer_note, offer_sent_at, confirmed_at, declined_by";

export const OFFER_NOTE_MAX = 500;

export const formatMoney = (amount: number | string | null | undefined, currency?: string | null, lang = "ro") => {
  const n = typeof amount === "string" ? Number(amount) : amount;
  if (n == null || !Number.isFinite(n)) return "—";
  const locale = lang.startsWith("ro") ? "ro-RO" : "en-GB";
  try {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency: currency || "RON",
      minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${n} ${currency || ""}`.trim();
  }
};

/** "Time: 18:00 - 23:00\n..." -> "18:00 - 23:00" */
export const extractTimeInterval = (message?: string | null): string | null => {
  if (!message || !message.startsWith("Time:")) return null;
  return message.split("\n")[0].replace("Time:", "").trim() || null;
};

const ERROR_TEXT: Record<string, string> = {
  BOOKING_NOT_FOUND: "This booking request could not be found.",
  BOOKING_NOT_OPEN: "This booking request is no longer open.",
  BOOKING_DATE_PASSED: "The event date has already passed.",
  BOOKING_NO_OPEN_OFFER: "There is no open offer for this booking.",
  OFFER_INVALID_PRICE: "Please enter a valid price.",
  OFFER_INVALID_CURRENCY: "Please choose a currency.",
  OFFER_NOTE_TOO_LONG: "The note must be 500 characters or fewer.",
  BOOKING_REQUIRES_ACCEPTED_OFFER: "Send an offer with a price. The booking is confirmed when the organizer accepts it.",
  CONTRACT_TERMS_NOT_ACCEPTED: "Please confirm that you agree to the contract terms.",
  CONTRACT_LOCATION_REQUIRED: "Please enter where the event takes place.",
  CONTRACT_DETAILS_REQUIRED: "Please fill in your contract details (name and address).",
  BOOKING_HAS_CONTRACT: "This booking has a contract and can't be deleted. You can cancel it instead.",
};

/** Maps a Supabase/RPC error to a user-facing English sentence (translated by the RO dictionary). */
export const offerErrorText = (error: unknown): string => {
  const msg = (error as { message?: string } | null)?.message ?? "";
  const code = Object.keys(ERROR_TEXT).find((k) => msg.includes(k));
  return code ? ERROR_TEXT[code] : "Something went wrong. Please try again.";
};

const escapeHtml = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

const formatLongDate = (ymd: string, lang: string) => {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(lang.startsWith("ro") ? "ro-RO" : "en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
};

/**
 * Opens a print-ready booking confirmation in a new window (the user can print or save it as PDF).
 * It is a summary of what both parties agreed on the platform, not a contract or an invoice.
 */
export const printBookingConfirmation = (
  booking: BookingOfferFields,
  artistName: string,
  lang: string = "ro"
) => {
  const ro = lang.startsWith("ro");
  const L = ro
    ? {
        title: "Confirmare de rezervare",
        number: "Nr.",
        artist: "Artist",
        organizer: "Organizator",
        date: "Data evenimentului",
        until: "până la",
        time: "Interval orar",
        type: "Tip eveniment",
        price: "Preț agreat",
        note: "Detalii ofertă",
        confirmed: "Confirmată pe",
        print: "Printează / salvează PDF",
        footer:
          "Document generat de Muzicalist pe baza ofertei trimise de artist și acceptate de organizator. Nu ține loc de contract sau de factură.",
      }
    : {
        title: "Booking confirmation",
        number: "No.",
        artist: "Artist",
        organizer: "Organizer",
        date: "Event date",
        until: "until",
        time: "Time",
        type: "Event type",
        price: "Agreed price",
        note: "Offer details",
        confirmed: "Confirmed on",
        print: "Print / save as PDF",
        footer:
          "Generated by Muzicalist from the offer sent by the artist and accepted by the organizer. It is not a contract or an invoice.",
      };

  const ref = booking.id.slice(0, 8).toUpperCase();
  const dateText =
    formatLongDate(booking.event_date, lang) +
    (booking.event_end_date && booking.event_end_date !== booking.event_date
      ? ` ${L.until} ${formatLongDate(booking.event_end_date, lang)}`
      : "");
  const time = extractTimeInterval(booking.message);
  const confirmed = booking.confirmed_at
    ? new Date(booking.confirmed_at).toLocaleString(ro ? "ro-RO" : "en-GB", { dateStyle: "long", timeStyle: "short" })
    : null;

  const rows: [string, string | null | undefined][] = [
    [L.artist, artistName],
    [L.organizer, booking.requester_name],
    [L.date, dateText],
    [L.time, time],
    [L.type, booking.event_type],
    [L.price, formatMoney(booking.offer_price, booking.offer_currency, lang)],
    [L.note, booking.offer_note],
    [L.confirmed, confirmed],
  ];

  const html = `<!doctype html><html lang="${ro ? "ro" : "en"}"><head><meta charset="utf-8">
<title>${escapeHtml(L.title)} ${escapeHtml(ref)}</title>
<style>
  *{box-sizing:border-box} body{font-family:Inter,Arial,sans-serif;color:#1d1b26;margin:0;padding:40px;max-width:720px}
  .brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:14px;letter-spacing:.08em;text-transform:uppercase;color:#9a6c08}
  .brand img{width:40px;height:40px;object-fit:contain}
  h1{font-size:26px;margin:8px 0 2px} .ref{color:#5c5a66;font-size:14px;margin-bottom:28px}
  table{width:100%;border-collapse:collapse} td{padding:10px 0;border-bottom:1px solid #e5e2ec;vertical-align:top;font-size:15px}
  td.k{width:38%;color:#5c5a66} td.v{font-weight:600;white-space:pre-wrap}
  .foot{margin-top:28px;font-size:12px;color:#5c5a66;line-height:1.5}
  button{margin-top:24px;padding:10px 18px;border:0;border-radius:8px;background:#9a6c08;color:#fff;font-size:14px;cursor:pointer}
  @media print{button{display:none} body{padding:0}}
</style></head><body>
<div class="brand"><img src="${MUZICALIST_LOGO_DATA_URI}" alt="Muzicalist"><span>Muzicalist</span></div>
<h1>${escapeHtml(L.title)}</h1>
<div class="ref">${escapeHtml(L.number)} ${escapeHtml(ref)}</div>
<table>${rows
    .filter(([, v]) => v)
    .map(([k, v]) => `<tr><td class="k">${escapeHtml(k)}</td><td class="v">${escapeHtml(String(v))}</td></tr>`)
    .join("")}</table>
<p class="foot">${escapeHtml(L.footer)}</p>
<button onclick="window.print()">${escapeHtml(L.print)}</button>
</body></html>`;

  const w = window.open("", "_blank");
  if (!w) return false;
  w.document.open();
  w.document.write(html);
  w.document.close();
  return true;
};
